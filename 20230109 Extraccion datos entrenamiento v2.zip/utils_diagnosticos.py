from typing import Union

from pyspark.sql import Column, DataFrame

from utils_spark import UtilsSpark
from utils_tarjeta import UtilsTarjeta
from pyspark.sql.functions import lit, when, current_date, min, date_format


class UtilsDiagnosticos:

    def __init__(self,
                 databricks: bool,
                 config_options: dict = None,
                 db_connection: dict = None,
                 dataframes: dict = None):
        """
        Instancia los dataframes usados para los cálculos. Hay solo dos posibilidades de construir este objeto,
        pasando los parámetros de la conexión con base de datos o pasando los dataframes necesarios directamente. Esto
        permite una versatilidad máxima a la hora de utilizar los métodos para nuestros cálculos. La conexión debe
        llevar obligatoriamente el driver, la url, el usuario y la contraseña de la conexión. Para los dataframes son
        opcionales cada uno de ellos.

        -------------
        Parameters:
        :param databricks: Booleano para saber si queremos emplear Databricks y adoptar ciertas opciones de Spark.
        :param config_options: Diccionario con las diferentes opciones de configuración.
        :param db_connection: Diccionario que debe tener las claves driver, url, user y password para conectar con
        una base de datos.
        :param dataframes: Diccionario con los dataframes que usarán los métodos de la clase (episodios, problusu,
        anteper, diagusu, etc.)
        """
        if (dataframes is None) & (db_connection is not None):
            utils_spark = UtilsSpark(databricks, config_options=config_options)
            utils_tarjeta = UtilsTarjeta(databricks, config_options=config_options, db_connection=db_connection)
            self.episodios = utils_spark.obtener_tabla(db_connection.get('driver'),
                                                       db_connection.get('url'),
                                                       db_connection.get('user'),
                                                       db_connection.get('password'), 'episodios')
            self.problusu = utils_spark.obtener_tabla(db_connection.get('driver'),
                                                      db_connection.get('url'),
                                                      db_connection.get('user'),
                                                      db_connection.get('password'), 'problusu')
            self.anteper = utils_spark.obtener_tabla(db_connection.get('driver'),
                                                     db_connection.get('url'),
                                                     db_connection.get('user'),
                                                     db_connection.get('password'), 'anteper')
            self.diagusu = utils_spark.obtener_tabla(db_connection.get('driver'),
                                                     db_connection.get('url'),
                                                     db_connection.get('user'),
                                                     db_connection.get('password'), 'diagusu')
            self.centros = utils_tarjeta.obtener_centros()
            self.ta_poblacion = utils_tarjeta.pacientes_tarjeta(date_format(current_date(), 'yyyy-mm-dd'))
        elif (dataframes is not None) & (db_connection is None):
            self.episodios = dataframes.get('episodios')
            self.problusu = dataframes.get('problusu')
            self.anteper = dataframes.get('anteper')
            self.diagusu = dataframes.get('diagusu')
            self.centros = dataframes.get('centros')
            self.pacientes = dataframes.get('ta_poblacion')
        else:
            raise AttributeError('Este constructor no es válido. Debe instanciar con los parámetros de una conexión ' +
                                 'o con los dataframes.')

    def obtener_episodios(self,
                          activos: bool,
                          codificacion_diag: str,
                          diagnosticos: Union[DataFrame, list, tuple],
                          columna_diagnostico: str,
                          fecha_activo: Column = current_date()) -> DataFrame:
        """
        Devuelve un DataFrame de Spark con información de los diagnósticos estén activos o no en episodios dada una
        lista de códigos de diagnóstico. Estos diagnósticos pueden ser dados en una lista, una tupla o incluso un
        DataFrame y deben pertenecer una codificación: diagnostico de la tabla diagnos_gen_e, CIE9 o id de la
        tabla hi_enfermedades. En el caso del DataFrame, es importante especificar la columna es la que se encuentran
        los códigos de diagnóstico. También podemos indicar una fecha que tiene dos comportamientos diferentes.
        Si queremos obtener los diagnósticos activos, la fecha representa que deben haber estado activo en ese
        momento. Si son todos, solo se contempla que estuviesen creados en ese momento. Por defecto, es la
        fecha actual. El cálculo de diagnóstico activo es algo complejo. Hay que tener en cuenta la fecha de
        activación, la fecha de desactivación y un campo de activo sí o no.

        -------------
        Parameters:
        :param activos: Booleano que representa si tenemos en cuenta solo los activos (True) o todos (False).
        :param codificacion_diag: Columna del diagnóstico en el que queremos buscar. Las opciones son: diagnostico,
        ccie9 o proceso.
        :param diagnosticos: Códigos de diagnóstico que queremos tener en cuenta.
        :param columna_diagnostico: Columna en la que se encuentran los códigos de diagnóstico en caso de que
        'diagnosticos' sea un DataFrame.
        :param fecha_activo: Fecha en la que queremos calcular que los diagnósticos se encontraban activos o,
        al menos, creados. Tiene que tener el formato 'yyyy-mm-dd'.
        :return: DataFrame con los episodios cuyo diangóstico está entre los especificados.
        """
        episodios = self.episodios
        diagusu = self.diagusu
        if type(diagnosticos) in [list, tuple]:
            episodios = episodios.where(episodios[codificacion_diag].isin(diagnosticos))
            diagusu = diagusu.where(diagusu[codificacion_diag].isin(diagnosticos))
        else:
            episodios = episodios.join(diagnosticos, episodios[codificacion_diag] == diagnosticos[columna_diagnostico])
            diagusu = diagusu.join(diagnosticos, diagusu[codificacion_diag] == diagnosticos[columna_diagnostico])

        diagusu = diagusu.select('num_episodio').distinct()
        episodios = episodios.join(diagusu,
                                   episodios['id_episodio'] == diagusu['num_episodio']).drop(diagusu['num_episodio'])

        if isinstance(fecha_activo, Column):
            episodios = episodios.where(episodios['fec_activacion'] <= fecha_activo)

        if activos:
            episodios = episodios.where((episodios['fec_desactivacion'].isNull() & episodios['epi_fecfus'].isNull()) |
                                        (when(episodios['fec_desactivacion'].isNull(),
                                              episodios['epi_fecfus'])
                                         .otherwise(episodios['fec_desactivacion']) > fecha_activo))
            episodios = episodios.where((when(episodios['fec_desactivacion'].isNull(),
                                              episodios['epi_fecfus'])
                                         .otherwise(episodios['fec_desactivacion']).isNotNull()) |
                                        ((episodios['activo'].isNull()) | (episodios['activo'] == 'S')))

        return episodios

    def obtener_problemas(self,
                          activos: bool,
                          codificacion_diag: str,
                          diagnosticos: Union[DataFrame, list, tuple],
                          columna_diagnostico: str,
                          fecha_activo: Column = current_date()) -> DataFrame:
        """
        Devuelve un DataFrame de Spark con información de los diagnósticos activos o no en problusu dada una
        lista de códigos de diagnóstico. Estos diagnósticos pueden ser dados en una lista, una tupla o incluso
        un DataFrame y deben pertenecer una codificación: diagnostico de la tabla diagnos_gen_e, CIE9 o id de
        la tabla hi_enfermedades. En el caso del DataFrame, es importante especificar la columna es la que
        se encuentran los códigos de diagnóstico. También podemos indicar una fecha que tiene dos comportamientos
        diferentes. Si queremos obtener los diagnósticos activos, la fecha representa que deben haber estado
        activo en ese momento. Si son todos, solo se contempla que estuviesen creados en ese momento. Por defecto,
        es la fecha actual. Este cálculo de diagnóstico activo tiene en cuenta la fecha de insersión y la
        fecha de desactivación.

        -------------
        Parameters:
        :param activos: Booleano que representa si tenemos en cuenta solo los activos (True) o todos (False).
        :param codificacion_diag: Columna del diagnóstico en el que queremos buscar. Las opciones son: codigo o proceso.
        :param diagnosticos: Códigos de diagnóstico que queremos tener en cuenta.
        :param columna_diagnostico: Columna en la que se encuentran los códigos de diagnóstico en caso de que
        'diagnosticos' sea un DataFrame.
        :param fecha_activo: Fecha en la que queremos calcular que los diagnósticos se encontraban activos o,
        al menos, creados. Tiene que tener el formato 'yyyy-mm-dd'.
        :return: DataFrame con los episodios cuyo diagnóstico está entre los especificados.
        """
        problusu = self.problusu

        if type(diagnosticos) in [list, tuple]:
            problusu = problusu.where(problusu[codificacion_diag].isin(diagnosticos))
        else:
            problusu = problusu.join(diagnosticos, problusu[codificacion_diag] == diagnosticos[columna_diagnostico])

        if isinstance(fecha_activo, Column):
            problusu = problusu.where(problusu['fecha_ide'] <= fecha_activo)
        if activos:
            problusu = problusu.where((problusu['fecha_res'].isNull()) | (problusu['fecha_res'] > fecha_activo))

        return problusu

    def obtener_anteper(self, codificacion_diag: str, diagnosticos: Union[DataFrame, list, tuple],
                        columna_diagnostico: str, fecha_filtro: Column = current_date()) -> DataFrame:
        """
        Devuelve un DataFrame de Spark con información de los diagnósticos estén activos o no en anteper dada una lista
        de códigos de diagnóstico. Estos diagnósticos pueden ser dados en una lista, una tupla o incluso un DataFrame
        y deben pertenecer una codificación: diagnostico de la tabla diagnos_gen_e, CIE9 o id de la tabla
        hi_enfermedades. En el caso del DataFrame, es importante especificar la columna es la que se encuentran los
        códigos de diagnóstico. También podemos indicar una fecha que tiene dos comportamientos diferentes. Si
        queremos obtener los diagnósticos activos, la fecha representa que deben haber estado activo en ese momento.
        Si son todos, solo se contempla que estuviesen creados en ese momento. Por defecto, es la fecha actual.
        El cálculo de diagnóstico activo es algo complejo. Hay que tener en cuenta la fecha de activación, la fecha
        de desactivación y un campo de activo sí o no.

        -------------
        Parameters:
        :param codificacion_diag: Columna del diagnóstico en el que queremos buscar. Las opciones son: codigo o proceso.
        :param diagnosticos: Códigos de diagnóstico que queremos tener en cuenta.
        :param columna_diagnostico: Columna en la que se encuentran los códigos de diagnóstico en caso de que
        'diagnosticos' sea un DataFrame.
        :param fecha_filtro: Fecha en la que queremos calcular que los diagnósticos se encontraban creados. Tiene que
        tener el formato 'yyyy-mm-dd'.
        :return: DataFrame con los episodios cuyo diangóstico está entre los especificados.
        """
        anteper = self.anteper
        if type(diagnosticos) in [list, tuple]:
            anteper = anteper.where(anteper[codificacion_diag].isin(diagnosticos))
        else:
            anteper = anteper.join(diagnosticos, anteper[codificacion_diag] == diagnosticos[columna_diagnostico])

        if isinstance(fecha_filtro, Column):
            anteper = anteper.where(anteper['fecha_ide'] <= fecha_filtro)

        return anteper

    def pacientes_con_diagnostico_activo_cie9(self,
                                              diagnosticos: Union[DataFrame, list, tuple],
                                              columna_diagnostico='cie9',
                                              fecha_activo: Column = current_date(),
                                              quitar_duplicados: bool = False) -> DataFrame:
        """
        Devuelve un DataFrame de Spark con información de los diagnósticos activos dada una lista de códigos de
        diagnóstico. Estos diagnósticos pueden ser dados en una lista, una tupla o incluso un DataFrame y
        deben pertenecer a la codificación CIE9. En el último caso, es importante especificar la columna es
        la que se encuentran los códigos de diagnóstico. También podemos indicar una fecha en la que calcular
        si estaban activos, aunque, por defecto, es la fecha actual.
        El método contiene una opción para quitar los registros duplicados que se pueden originar al unir
        episodios con problusu. En teoría, un registro en problusu debería tener su equivalente en episodios,
        pero, por inconsistencia de datos esto no es así en la realidad. Por eso buscamos en ambas tablas y las
        unimos. Esta operación puede originar diagnósticos duplicados para los que esta teoría sí se aplica.
        Como quitarlos es un proceso muy costoso y puede no ser necesario si se aplica un conteo de distintos
        pacientes al resultado, dejamos a elección del usuario si aplicar o no este filtro.

        -------------
        Parameters:
        :param diagnosticos: Códigos de diagnóstico que queremos tener en cuenta.
        :param columna_diagnostico: Columna en la que se encuentran los códigos de diagnóstico en caso de que
        'diagnosticos' sea un DataFrame.
        :param fecha_activo: Fecha en la que queremos calcular que los diagnósticos se encontraban activos.
        Tiene que tener el formato 'yyyy-mm-dd'.
        :param quitar_duplicados: Booleano para saber si se desea quitar los posibles duplicados. Por defecto, no
        los quitamos.
        :return: DataFrame con los diagnósticos activos a partir de la codificación CIE9
        """
        episodios = self.obtener_episodios(True, 'ccie9', diagnosticos, columna_diagnostico, fecha_activo)
        problusu = self.obtener_problemas(True, 'codigo', diagnosticos, columna_diagnostico, fecha_activo)

        union_diagnosticos = unir_episodios_problusu(episodios, problusu)

        if quitar_duplicados:
            union_diagnosticos = filtrar_diagnosticos_duplicados(union_diagnosticos, columna_cod_diagnostico='ccie9')

        return union_diagnosticos

    def pacientes_con_diagnostico_cie9(self,
                                       diagnosticos: Union[DataFrame, list, tuple],
                                       columna_diagnostico='cie9',
                                       fecha_creado: Column = current_date(),
                                       quitar_duplicados: bool = False) -> DataFrame:
        """
        Devuelve un DataFrame de Spark con información de los diagnósticos activos y no activos dada una lista
        de códigos de diagnóstico. Estos diagnósticos pueden ser dados en una lista, una tupla o incluso un
        DataFrame y deben pertenecer a la codificación CIE9. En el último caso, es importante especificar la
        columna es la que se encuentran los códigos de diagnóstico. También podemos indicar una fecha en la
        que calcular si estaban creados, aunque, por defecto, es la fecha actual.
        El método contiene una opción para quitar los registros duplicados que se pueden originar al unir
        episodios con problusu. En teoría, un registro en problusu debería tener su equivalente en episodios,
        pero, por inconsistencia de datos esto no es así en la realidad. Por eso buscamos en las tres tablas y las
        unimos. Esta operación puede originar diagnósticos duplicados para los que esta teoría sí se aplica.
        Como quitarlos es un proceso muy costoso y puede no ser necesario si se aplica un conteo de distintos
        pacientes al resultado, dejamos a elección del usuario si aplicar o no este filtro.

        -------------
        Parameters:
        :param diagnosticos: Códigos de diagnóstico que queremos tener en cuenta.
        :param columna_diagnostico: Columna en la que se encuentran los códigos de diagnóstico en caso de que
        'diagnosticos' sea un DataFrame.
        :param fecha_creado: Fecha en la que queremos calcular que los diagnósticos se encontraban creados.
        Tiene que tener el formato 'yyyy-mm-dd'.
        :param quitar_duplicados: Booleano para saber si se desea quitar los posibles duplicados. Por defecto, no
        los quitamos.
        :return: DataFrame con los diagnósticos activos o no a partir de la codificación CIE9
        """
        episodios = self.obtener_episodios(False, 'ccie9', diagnosticos, columna_diagnostico, fecha_creado)
        problusu = self.obtener_problemas(False, 'codigo', diagnosticos, columna_diagnostico, fecha_creado)
        anteper = self.obtener_anteper('codigo', diagnosticos, columna_diagnostico, fecha_creado)

        union_diagnosticos = unir_episodios_problusu_anteper(episodios, problusu, anteper)

        if quitar_duplicados:
            union_diagnosticos = filtrar_diagnosticos_duplicados(union_diagnosticos, columna_cod_diagnostico='ccie9')

        return union_diagnosticos

    def pacientes_con_diagnostico_activo_proceso(self,
                                                 diagnosticos: Union[DataFrame, list, tuple],
                                                 columna_diagnostico='proceso',
                                                 fecha_activo: Column = current_date(),
                                                 quitar_duplicados: bool = False) -> DataFrame:
        """
        Devuelve un DataFrame de Spark con información de los diagnósticos activos dada una lista de códigos
        de diagnóstico. Estos diagnósticos pueden ser dados en una lista, una tupla o incluso un DataFrame y
        deben pertenecer a la codificación del ID de hi_enfermedades. En el último caso, es importante especificar
        la columna es la que se encuentran los códigos de diagnóstico. También podemos indicar una fecha en
        la que calcular si estaban activos, aunque, por defecto, es la fecha actual.
        El método contiene una opción para quitar los registros duplicados que se pueden originar al unir
        episodios con problusu. En teoría, un registro en problusu debería tener su equivalente en episodios,
        pero, por inconsistencia de datos esto no es así en la realidad. Por eso buscamos en ambas tablas y las
        unimos. Esta operación puede originar diagnósticos duplicados para los que esta teoría sí se aplica.
        Como quitarlos es un proceso muy costoso y puede no ser necesario si se aplica un conteo de distintos
        pacientes al resultado, dejamos a elección del usuario si aplicar o no este filtro.

        -------------
        Parameters:
        :param diagnosticos: Códigos de diagnóstico que queremos tener en cuenta.
        :param columna_diagnostico: Columna en la que se encuentran los códigos de diagnóstico en caso de que
        'diagnosticos' sea un DataFrame.
        :param fecha_activo: Fecha en la que queremos calcular que los diagnósticos se encontraban activos.
        Tiene que tener el formato 'yyyy-mm-dd'.
        :param quitar_duplicados: Booleano para saber si se desea quitar los posibles duplicados. Por defecto, no
        los quitamos.
        :return: DataFrame con los diagnósticos activos a partir de la codificación CIE9
        """
        episodios = self.obtener_episodios(True, 'proceso', diagnosticos, columna_diagnostico, fecha_activo)
        problusu = self.obtener_problemas(True, 'proceso', diagnosticos, columna_diagnostico, fecha_activo)

        union_diagnosticos = unir_episodios_problusu(episodios, problusu)

        if quitar_duplicados:
            union_diagnosticos = filtrar_diagnosticos_duplicados(union_diagnosticos, columna_cod_diagnostico='proceso')

        return union_diagnosticos

    def pacientes_con_diagnostico_proceso(self,
                                          diagnosticos: Union[DataFrame, list, tuple],
                                          columna_diagnostico='proceso',
                                          fecha_creado: Column = current_date(),
                                          quitar_duplicados: bool = False) -> DataFrame:
        """
        Devuelve un DataFrame de Spark con información de los diagnósticos activos y no activos dada una lista de
        códigos de diagnóstico. Estos diagnósticos pueden ser dados en una lista, una tupla o incluso un
        DataFrame y deben pertenecer al ID de la tabla de hi_enfermedades. En el último caso, es importante
        especificar la columna es la que se encuentran los códigos de diagnóstico. También podemos indicar una
        fecha en la que calcular si estaban creados, aunque, por defecto, es la fecha actual.
        El método contiene una opción para quitar los registros duplicados que se pueden originar al unir
        episodios con problusu. En teoría, un registro en problusu debería tener su equivalente en episodios,
        pero, por inconsistencia de datos esto no es así en la realidad. Por eso buscamos en ambas tablas y las
        unimos. Esta operación puede originar diagnósticos duplicados para los que esta teoría sí se aplica.
        Como quitarlos es un proceso muy costoso y puede no ser necesario si se aplica un conteo de distintos
        pacientes al resultado, dejamos a elección del usuario si aplicar o no este filtro.

        -------------
        Parameters:
        :param diagnosticos: Códigos de diagnóstico que queremos tener en cuenta.
        :param columna_diagnostico: Columna en la que se encuentran los códigos de diagnóstico en caso de que
        'diagnosticos' sea un DataFrame.
        :param fecha_creado: Fecha en la que queremos calcular que los diagnósticos se encontraban creados.
        Tiene que tener el formato 'yyyy-mm-dd'.
        :param quitar_duplicados: Booleano para saber si se desea quitar los posibles duplicados. Por defecto, no
        los quitamos.
        :return: DataFrame con los diagnósticos activos o no a partir del ID de hi_enfermedades
        """
        episodios = self.obtener_episodios(False, 'proceso', diagnosticos, columna_diagnostico, fecha_creado)
        problusu = self.obtener_problemas(False, 'proceso', diagnosticos, columna_diagnostico, fecha_creado)
        anteper = self.obtener_anteper('proceso', diagnosticos, columna_diagnostico, fecha_creado)

        union_diagnosticos = unir_episodios_problusu_anteper(episodios, problusu, anteper)

        if quitar_duplicados:
            union_diagnosticos = filtrar_diagnosticos_duplicados(union_diagnosticos, columna_cod_diagnostico='proceso')

        return union_diagnosticos

    """
     - Un metodo que devuelva la prevalencia
     - Otro que devuelva la incidencia
        - Parametros
            * Ambos se les puede especificar si solo se busca por id de hi inferemedades o si hay que buscar por ambos (id y cie9). En 
     este último caso se deberá eliminar las repeticiones.
            * Por sexo
            * Por edades
            * Por que se agrupa
            * Por area
            * Que calcule el mes año, incidencia por mes, agregar columna mes en cada fecha -- substring(date_format(interconsultas_gc_tfe['fec_sol'], 'yyyy-MM-dd'), 0, 7)
            
            * Por fecha
     
     - Tener en cuenta si es numero de pacientes o numero de diagnosticos
    """

    def pacientes_prevalencia(self,
                              diagnosticos_cie9: Union[DataFrame, list, tuple],
                              diagnosticos_proceso: Union[DataFrame, list, tuple],
                              identificador_diagnos=None,
                              columna_proceso='proceso',
                              columna_cie9='cie9',
                              columnas_group_by: list = None,
                              fecha_activo: Column = current_date(),
                              contar_personas: bool = False,
                              quitar_duplicados: bool = False) -> DataFrame:
        """
        Devuelve un DataFrame o un entero de Spark con información de la prevalencia dada una lista de códigos
        de diagnóstico. Estos diagnósticos pueden ser dados en una lista, una tupla o incluso un DataFrame y
        pueden pertenecer a la codificación del ID de hi_enfermedades o de cie9. En el último caso, es importante especificar
        la columna es la que se encuentran los códigos de diagnóstico. También podemos indicar una fecha en
        la que calcular si estaban activos, aunque, por defecto, es la fecha actual. El método permite agrupar por determinados
        campos si así se requiere. Además, contiene una opción para quitar los registros duplicados que se pueden originar al unir
        episodios con problusu. En teoría, un registro en problusu debería tener su equivalente en episodios,
        pero, por inconsistencia de datos esto no es así en la realidad. Por eso buscamos en ambas tablas y las
        unimos. Esta operación puede originar diagnósticos duplicados para los que esta teoría sí se aplica.
        Como quitarlos es un proceso muy costoso y puede no ser necesario si se aplica un conteo de distintos
        pacientes al resultado, dejamos a elección del usuario si aplicar o no este filtro.

        -------------
        Parameters:
        :param diagnosticos: Códigos de diagnóstico que queremos tener en cuenta.
        :param identificador_diagnos: Palabra clave para saber si se busca por id, por cie9 o por ambos.
        :param columna_proceso: Columna en la que se encuentran los id de diagnóstico en caso de que 'diagnosticos' sea un DataFrame.
        :param columna_cie9:  Columna en la que se encuentran los códigos cie9 de diagnóstico en caso de que 'diagnosticos' sea un DataFrame.
        :param columnas_group_by: Lista de columnas por las que se debe agrupar el resultado.
        :param fecha_activo: Fecha en la que queremos calcular que los diagnósticos se encontraban activos.
        :param contar_personas: Booleano que indica si debemos contar los nº de expediente o el nº de diagnósticos. 
        :param quitar_duplicados: Booleano para saber si se desea quitar los posibles duplicados. Por defecto, no los quitamos.

        :return: DataFrame con la prevalencia de los diagnósticos dados
        """
        centros = self.centros.select('are_cod_area', 'cod_cias_centro')
        pacientes = self.pacientes
        pacientes = pacientes.where((pacientes['fec_fallecimiento'].isNull()) | (pacientes['fec_fallecimiento'] >= fecha_activo))

        if identificador_diagnos == 'id':
            prevalencia = self.pacientes_con_diagnostico_activo_proceso(diagnosticos=diagnosticos_proceso,
                                                                        columna_diagnostico=columna_proceso,
                                                                        fecha_activo=fecha_activo,
                                                                        quitar_duplicados=quitar_duplicados)
        elif identificador_diagnos == 'cie9':
            prevalencia = self.pacientes_con_diagnostico_activo_cie9(diagnosticos=diagnosticos_cie9,
                                                                     columna_diagnostico=columna_cie9,
                                                                     fecha_activo=fecha_activo,
                                                                     quitar_duplicados=quitar_duplicados)
        else:
            prevalencia_cie9 = self.pacientes_con_diagnostico_activo_cie9(diagnosticos=diagnosticos_cie9,
                                                                          columna_diagnostico=columna_cie9,
                                                                          fecha_activo=fecha_activo,
                                                                          quitar_duplicados=quitar_duplicados)
            prevalencia_proceso = self.pacientes_con_diagnostico_activo_proceso(diagnosticos=diagnosticos_proceso,
                                                                                columna_diagnostico=columna_proceso,
                                                                                fecha_activo=fecha_activo,
                                                                                quitar_duplicados=quitar_duplicados)
            prevalencia = prevalencia_proceso.union(prevalencia_cie9)

        prevalencia.show()
        prevalencia = prevalencia.join(pacientes, prevalencia['num_expediente'] == pacientes['num_expediente']).drop(
            pacientes['num_expediente'])
        prevalencia = prevalencia.join(centros, prevalencia['cod_centro'] == centros['cod_cias_centro'])
        prevalencia.show()

        if contar_personas and columnas_group_by:
            prevalencia = prevalencia.groupBy(columnas_group_by).agg(countDistinct('num_expediente')).withColumnRenamed(
                'count(num_expediente)', 'Prevalencia')
        elif not columnas_group_by and contar_personas:
            prevalencia = prevalencia.select('num_expediente').distinct().count()
        elif not contar_personas and columnas_group_by:
            prevalencia = prevalencia.groupBy(columnas_group_by).count('id').withColumnRenamed('count(id)',
                                                                                               'Prevalencia')
        else:
            prevalencia = prevalencia.select('id').count()
        # prevalencia.show()

        return prevalencia

    def pacientes_incidencia(self,
                             diagnosticos: Union[DataFrame, list, tuple],
                             identificador_diagnos=None,
                             columna_proceso='proceso',
                             columna_cie9='cie9',
                             columnas_group_by: list = None,
                             fecha_inicio: Column = None,
                             fecha_fin: Column = current_date(),
                             contar_personas: bool = False,
                             quitar_duplicados: bool = False) -> DataFrame:
        """
        Devuelve un DataFrame o un entero de Spark con información de la incidencia dada una lista de códigos
        de diagnóstico. Estos diagnósticos pueden ser dados en una lista, una tupla o incluso un DataFrame y
        pueden pertenecer a la codificación del ID de hi_enfermedades o de cie9. En el último caso, es importante especificar
        la columna es la que se encuentran los códigos de diagnóstico. Debemos indicar dos fechas, que indican el periodo en el que
        se quiere calcular la incidencia, fecha de inicio del periodo y fecha de fin del mismo. El método permite agrupar por determinados
        campos si así se requiere. Además, contiene una opción para quitar los registros duplicados que se pueden originar al unir
        episodios con problusu. En teoría, un registro en problusu debería tener su equivalente en episodios,
        pero, por inconsistencia de datos esto no es así en la realidad. Por eso buscamos en ambas tablas y las
        unimos. Esta operación puede originar diagnósticos duplicados para los que esta teoría sí se aplica.
        Como quitarlos es un proceso muy costoso y puede no ser necesario si se aplica un conteo de distintos
        pacientes al resultado, dejamos a elección del usuario si aplicar o no este filtro.

        -------------
        Parameters:
        :param diagnosticos: Códigos de diagnóstico que queremos tener en cuenta.
        :param identificador_diagnos: Palabra clave para saber si se busca por id, por cie9 o por ambos.
        :param columna_proceso: Columna en la que se encuentran los id de diagnóstico en caso de que 'diagnosticos' sea un DataFrame.
        :param columna_cie9:  Columna en la que se encuentran los códigos cie9 de diagnóstico en caso de que 'diagnosticos' sea un DataFrame.
        :param columnas_group_by: Lista de columnas por las que se debe agrupar el resultado.
        :param fecha_inicio: Fecha de inicio del periodo para calcular la incidencia.
        :param fecha_fin: Fecha de fin del periodo para calcular la incidencia.
        :param contar_personas: Booleano que indica si debemos contar los nº de expediente o el nº de diagnósticos. 
        :param quitar_duplicados: Booleano para saber si se desea quitar los posibles duplicados. Por defecto, no los quitamos.

        :return: DataFrame con la prevalencia de los diagnósticos dados
        """
        pacientes = self.pacientes
        centros = self.centros.select('are_cod_area', 'cod_cias_centro')

        incidencia_proceso = self.pacientes_con_diagnostico_activo_proceso(diagnosticos=diagnosticos,
                                                                           columna_diagnostico=columna_proceso,
                                                                           fecha_activo=fecha_inicio,
                                                                           quitar_duplicados=quitar_duplicados)
        incidencia_cie9 = self.pacientes_con_diagnostico_activo_cie9(diagnosticos=diagnosticos,
                                                                     columna_diagnostico=columna_cie9,
                                                                     fecha_activo=fecha_inicio,
                                                                     quitar_duplicados=quitar_duplicados)

        if identificador_diagnos == 'id':
            incidencia = incidencia_proceso
        elif identificador_diagnos == 'cie9':
            incidencia = incidencia_cie9
        else:
            incidencia = incidencia_proceso.union(incidencia_cie9)

        if fecha_inicio and fecha_fin:
            incidencia = incidencia.where(
                (incidencia['fec_activacion'] >= lit(fecha_inicio)) & (incidencia['fec_activacion'] <= lit(fecha_fin)))

        incidencia = incidencia.join(pacientes, incidencia['num_expediente'] == pacientes['num_expediente']).drop(
            pacientes['num_expediente'])
        incidencia = incidencia.join(centros, incidencia['mec_cen_cod_cias_centro'] == centros['cod_cias_centro'])

        if contar_personas and columnas_group_by:
            incidencia = incidencia.groupBy(columnas_group_by).agg(countDistinct('num_expediente')).withColumnRenamed(
                'count(num_expediente)', 'Prevalencia')
        elif not columnas_group_by and contar_personas:
            incidencia = incidencia.select('num_expediente').distinct().count()
        elif not contar_personas and columnas_group_by:
            incidencia = incidencia.groupBy(columnas_group_by).count('id').withColumnRenamed('count(id)', 'Prevalencia')
        else:
            incidencia = incidencia.select('id').count()

        return incidencia.withColumn(substring(date_format(incidencia['fec_activacion'], 'yyyy-MM-dd'), 0, 7))


def unir_episodios_problusu(episodios: DataFrame,
                            problusu: DataFrame) -> DataFrame:
    """
    Las tablas de episodios y problusu representan información casi equivalente, ambos contienen diagósticos
    asociados a pacientes. Estos solo se diferencian en el estado del diagnóstico para los pacientes. En
    episodios tenemos los diagnósticos en un estado normal, mientras que en problusu tenemos lo que se llaman
    problemas fundamentales. Aunque representan estados diferentes, sus características son las mismas. Es por
    eso que tiene sentido querer manejarlas en un único DataFrame. El procedimiento que llevamos a cabo es
    realizar una equivalencia de columnas entre ambas tablas para luego aplicar la unión.

    -------------
    Parameters:
    :param episodios: DataFrame originado a través de la tabla episodios.
    :param problusu: DataFrame originado a través de la tabla problusu.
    :return: Unión de los DataFrames de episodios y problusu con las mismas columnas.
    """
    episodios = episodios.select(['id_episodio', 'num_expediente', 'ccie9', 'proceso', 'fec_activacion',
                                  'fec_desactivacion', 'epi_num_visita', 'descripcion', 'diagnostico'])
    problusu = problusu.select(['id_problusu', 'contador', 'codigo', 'proceso', 'fecha_ide', 'fecha_res',
                                'num_visita', 'problema'])

    episodios = episodios.withColumnRenamed('id_episodio', 'id')
    episodios = episodios.withColumnRenamed('epi_num_visita', 'num_visita')
    problusu = problusu.withColumnRenamed('id_problusu', 'id')
    problusu = problusu.withColumnRenamed('contador', 'num_expediente')
    problusu = problusu.withColumnRenamed('codigo', 'ccie9')
    problusu = problusu.withColumn('diagnostico', lit(None))
    problusu = problusu.withColumnRenamed('fecha_ide', 'fec_activacion')
    problusu = problusu.withColumnRenamed('fecha_res', 'fec_desactivacion')
    problusu = problusu.withColumnRenamed('problema', 'descripcion')

    episodios = episodios.withColumn('tabla', lit('episodios'))
    problusu = problusu.withColumn('tabla', lit('problusu'))

    return episodios.union(problusu)


def unir_episodios_problusu_anteper(episodios: DataFrame,
                                    problusu: DataFrame, anteper: DataFrame) -> DataFrame:
    """
    Las tablas de episodios y problusu representan información casi equivalente, ambos contienen diagósticos
    asociados a pacientes. Estos solo se diferencian en el estado del diagnóstico para los pacientes. En
    episodios tenemos los diagnósticos en un estado normal, mientras que en problusu tenemos lo que se llaman
    problemas fundamentales. Aunque representan estados diferentes, sus características son las mismas. Es por
    eso que tiene sentido querer manejarlas en un único DataFrame. El procedimiento que llevamos a cabo es
    realizar una equivalencia de columnas entre ambas tablas para luego aplicar la unión.

    -------------
    Parameters:
    :param episodios: DataFrame originado a través de la tabla episodios.
    :param problusu: DataFrame originado a través de la tabla problusu.
    :return: Unión de los DataFrames de episodios y problusu con las mismas columnas.
    """
    episodios = episodios.select(['id_episodio', 'num_expediente', 'ccie9', 'proceso', 'fec_activacion',
                                  'fec_desactivacion', 'epi_num_visita', 'descripcion', 'diagnostico'])
    problusu = problusu.select(['id_problusu', 'contador', 'codigo', 'proceso', 'fecha_ide', 'fecha_res',
                                'num_visita', 'problema'])
    anteper = anteper.select('id_anteper', 'contador', 'codigo', 'proceso', 'fecha_ide', 'fecha_res', 'num_visita',
                             'problema')

    episodios = episodios.withColumnRenamed('id_episodio', 'id')
    episodios = episodios.withColumnRenamed('epi_num_visita', 'num_visita')
    problusu = problusu.withColumnRenamed('id_problusu', 'id')
    problusu = problusu.withColumnRenamed('contador', 'num_expediente')
    problusu = problusu.withColumnRenamed('codigo', 'ccie9')
    problusu = problusu.withColumn('diagnostico', lit(None))
    problusu = problusu.withColumnRenamed('fecha_ide', 'fec_activacion')
    problusu = problusu.withColumnRenamed('fecha_res', 'fec_desactivacion')
    problusu = problusu.withColumnRenamed('problema', 'descripcion')
    anteper = anteper.withColumn('diagnostico', lit(None))
    anteper = anteper.withColumnRenamed('problema', 'descripcion')
    anteper = anteper.withColumnRenamed('contador', 'num_expediente')
    anteper = anteper.withColumnRenamed('codigo', 'ccie9')
    anteper = anteper.withColumnRenamed('fecha_ide', 'fec_activacion')
    anteper = anteper.withColumnRenamed('fecha_res', 'fec_desactivacion')

    episodios = episodios.withColumn('tabla', lit('episodios'))
    problusu = problusu.withColumn('tabla', lit('problusu'))
    anteper = anteper.withColumn('tabla', lit('anteper'))

    return episodios.union(problusu).union(anteper)


def filtrar_diagnosticos_duplicados(diagnosticos: DataFrame,
                                    columna_paciente: str = 'num_expediente',
                                    columna_cod_diagnostico: str = 'proceso',
                                    columna_fecha: str = 'fec_activacion') -> DataFrame:
    """
    Método encargado de eliminar los duplicados en los diagnósticos. Consideramos que un diagnóstico está
    duplicado si, para un mismo paciente, existen dos filas con exactamente el mismo código de diagnóstico,
    aunque sea en fecha distinta. Este proceso de filtrado es muy costoso así que recomendamos usarlo solo
    si es realmente necesario. Este filtrado solo es necesario por las inconsistencias que existen en BBDD.
    El procedimiento es simple; ordenamos por fecha del diagnóstico (más antigua primero) y quitamos los
    duplicados basándonos en el número de expediente y el código del diagnóstico. Al ordenar por fecha, deja el
    primer registro, es decir, el más antiguo.

    -------------
    Parameters:
    :param diagnosticos: DataFrame con los diagnósticos de personas.
    :param columna_paciente: Nombre de la columna del DataFrame que contienen el número de expediente de usuario.
    :param columna_cod_diagnostico: Nombre de la columna del DataFrame que contienen el código de diagnóstico.
    :param columna_fecha: Nombre de la columna del DataFrame que contiene la fecha del diagnóstico.
    :return: DataFrame con los diagnósticos sin duplicidades.
    """

    filtrado = diagnosticos.orderBy(columna_fecha, ascending=True)
    filtrado = filtrado.dropDuplicates([columna_paciente, columna_cod_diagnostico])
    return filtrado
