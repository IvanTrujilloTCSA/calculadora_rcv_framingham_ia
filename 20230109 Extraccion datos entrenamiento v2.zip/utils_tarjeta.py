from pyspark.sql import DataFrame
from pyspark.sql.column import Column
from pyspark.sql.functions import floor, datediff, lit, current_date
from utils_spark import UtilsSpark


class UtilsTarjeta:

    def __init__(self,
                 databricks: bool,
                 config_options: dict = None,
                 db_connection: dict = None,
                 dataframes: dict = None):
        """
        Constructor que instancia los dataframes usados para los cálculos. Hay solo dos posibilidades de construir
        este objeto, pasando los parámetros de la conexión con base de datos o pasando los dataframes necesarios
        directamente. Esto permite una versatilidad máxima a la hora de utilizar los métodos para nuestros cálculos.
        La conexión debe llevar obligatoriamente el driver, la url, el usuario y la contraseña de la conexión.
        Para los dataframes son opcionales cada uno de ellos.

        -------------
        Parameters:
        :param databricks: Booleano para saber si queremos emplear Databricks y adoptar ciertas opciones de Spark.
        :param config_options: Diccionario con las diferentes opciones de configuración.
        :param db_connection: Diccionario que debe tener las claves driver, url, user y password para conectar con
        una base de datos.
        :param dataframes: Diccionario con los dataframes que usarán los métodos de la clase (ta_tarjetas,
        ta_poblacion, ta_centros_publicos, etc.)
        """
        if (dataframes is None) & (db_connection is not None):
            utils_spark = UtilsSpark(databricks, config_options=config_options)
            self.ta_no_replicar = utils_spark.obtener_tabla(db_connection.get('driver'),
                                                            db_connection.get('url'),
                                                            db_connection.get('user'),
                                                            db_connection.get('password'),
                                                            'ta_no_replicar')
            self.ta_centros_publicos = utils_spark.obtener_tabla(db_connection.get('driver'),
                                                                 db_connection.get('url'),
                                                                 db_connection.get('user'),
                                                                 db_connection.get('password'),
                                                                 'ta_centros_publicos')
            self.ta_tarjetas = utils_spark.obtener_tabla(db_connection.get('driver'),
                                                         db_connection.get('url'),
                                                         db_connection.get('user'),
                                                         db_connection.get('password'),
                                                         'ta_tarjetas')
            self.ta_poblacion = utils_spark.obtener_tabla(db_connection.get('driver'),
                                                          db_connection.get('url'),
                                                          db_connection.get('user'),
                                                          db_connection.get('password'),
                                                          'ta_poblacion')
            self.ta_zonas = utils_spark.obtener_tabla(db_connection.get('driver'),
                                                      db_connection.get('url'),
                                                      db_connection.get('user'),
                                                      db_connection.get('password'),
                                                      'ta_zonas')
            
        elif (dataframes is not None) & (db_connection is None):
            self.ta_no_replicar = dataframes.get('ta_no_replicar')
            self.ta_centros_publicos = dataframes.get('ta_centros_publicos')
            self.ta_tarjetas = dataframes.get('ta_tarjetas')
            self.ta_poblacion = dataframes.get('ta_poblacion')
            self.ta_zonas = dataframes.get('ta_zonas')
        else:
            raise AttributeError(
                'Este constructor no es válido. Debe instanciar con los parámetros de una conexión o con dataframes.')

    def pacientes_ficticios(self) -> DataFrame:
        """
        Suele ser muy habitual que en las tablas de pacientes haya pacientes de prueba o ficticios que queremos
        sacar de nuestras estadísticas. Esta función obtiene los registros de la tabla 'ta_no_replicar' y
        devuelve los números de expediente de los ficticios.

        -------------
        Parameters:
        :return: DataFrame
        """
        no_replicar = self.ta_no_replicar
        return no_replicar.where(no_replicar['motivo_blq'] == 1).select(['num_expediente'])

    def obtener_centros(self, area: str = 'todas', zbs: bool = False):
        """
        Suele ser habitual que pidan datos agrupados por áreas de salud que son simplemente las 7 Islas Canarias.
        También piden información por centros y las tablas, por la normalización, solo tienen el código del centro
        que, para un usuario no técnico, no tienen ningún significado. Aquí obtenemos los centros públicos de
        Atención Primaria y únicamente devolvemos su código, el nombre y el área a la que pertenece. Por defecto,
        obtenemos todos los centros, pero si le indicamos un área, obtendrá los centros de esa área solamente. También
        podemos obtener las zonas básicas de Salud si lo indicamos.

        -------------
        Parameters:
        :param area: El código del área del que queremos obtener los centros. Por defecto es 'todas' para obtener
        todos los centros de todas las áreas. Los posibles valores que puede tener son 'fue', 'gom', 'hie', 'lan',
        'lpa', 'pal' y 'tfe', indistintamente de mayúsculas o minúsculas.
        :param zbs: Booleano para indicar si obtener las zonas básicas de salud de cada centro.
        :return: DataFrame con los centros, sus áreas y su ZBS.
        """
        centros = self.ta_centros_publicos
        if area.lower() != 'todas':
            centros = centros.where(centros['are_cod_area'] == area.upper())
        if zbs:
            zonas = self.ta_zonas.select('cod_zona', 'des_zona')
            centros = centros.join(zonas, centros['zon_cod_zona'] == zonas['cod_zona'])
            centros = centros.withColumnRenamed('des_zona', 'zbs')
            centros = centros.select(['cod_cias_centro', 'are_cod_area', 'des_centro_pub', 'zbs'])
        else:
            centros = centros.select(['cod_cias_centro', 'are_cod_area', 'des_centro_pub'])
        return centros

    def pacientes_tarjeta(self, fecha: Column = None) -> DataFrame:
        """
        Esta función se encarga de devolver los pacientes con Tarjeta Sanitaria. Si no especificamos una fecha, lo hará
        según los pacientes con T.S. en el día actual (como utilizamos la base de datos de COPIA realmente será a
        finales del mes pasado). Si le especificamos una fecha, calculará los pacientes con T.S. en esa fecha. Además,
        quitará los pacientes ficticios y devolverá solo algunos campos que suelen ser necesarios, incluida la edad.

        -------------
        Parameters:
        :param fecha: Fecha en str en la que queremos obtener los pacientes con T.S. Debe tener el formato 'yyyy-mm-dd'.
        :return: DataFrame
        """
        if isinstance(fecha, Column):
            pacientes = self.ta_poblacion
            pacientes = pacientes.where(pacientes['cod_cias_medico'].isNotNull())
            pacientes = pacientes.where(
                (pacientes['fec_fallecimiento'] > lit(fecha)) | pacientes['fec_fallecimiento'].isNull())
            pacientes = pacientes.select(
                ['num_expediente', 'cod_sexo', 'fec_nacimiento', 'fec_fallecimiento', 'cod_cias_medico',
                 'cod_centro', 'cip_cbr', 'cod_dni_nie', 'des_nombre', 'des_apellido1', 'des_apellido2',
                 'tfno_principal1', 'tfno_principal2', 'tfno_temporal1', 'des_direccion_principal'])
            pacientes = self.calcular_edad(pacientes, 'fec_nacimiento', lit(fecha))
        else:
            pacientes = self.ta_tarjetas
            pacientes = pacientes.select(['num_expediente', 'cod_sexo', 'fec_nacimiento', 'mec_cod_cias_medico',
                                          'mec_cen_cod_cias_centro', 'cod_cip', 'cod_dni_nie', 'des_nombre',
                                          'des_apellido1', 'des_apellido2', 'num_telef_ppal', 'num_telefono1',
                                          'num_telefono2', 'des_direccion'])
            pacientes = self.calcular_edad(pacientes, 'fec_nacimiento')

        pacientes_prueba = self.pacientes_ficticios()
        pacientes = pacientes.join(pacientes_prueba,
                                   pacientes['num_expediente'] == pacientes_prueba['num_expediente'],
                                   how='left_anti')

        return pacientes

    def calcular_edad(self,
                      tabla: DataFrame,
                      columna_fecha_nacimiento: str,
                      fecha_calculo_edad: Column = current_date()) -> DataFrame:
        """
        Un cálculo habitual en la explotación de datos es calcular la edad a partir de la fecha de
        nacimiento de un paciente. Por ese motivo es útil esta función que recibe un DataFrame y
        devuelve el mismo DataFrame con una columna adicional llamada 'edad' con la edad de la
        persona. Como no podemos saber cómo se llama la columna que tiene la fecha de nacimiento
        la solicitamos con un parámetro adicional. Esa columna debe tener el formato fecha. Además,
        podríamos necesitar calcular la edad en una fecha determinada, aunque, por defecto, se calcula
        en la fecha actual.

        -------------
        Parameters:
        :param tabla: DataFrame que contiene la fecha de nacimiento.
        :param columna_fecha_nacimiento: Nombre de la columna con la fecha de nacimiento.
        :param fecha_calculo_edad: Fecha en la que queremos calcular la edad de la persona. Por defecto, la fecha actual.
        Debe ser una columna, por lo que se puede usar la función lit() para convertir un str en una columna con
        las fechas en formato 'yyyy-mm-dd'.
        :return: DataFrame
        """
        return tabla.withColumn('edad', floor(datediff(fecha_calculo_edad, tabla[columna_fecha_nacimiento]) / 365.25))
