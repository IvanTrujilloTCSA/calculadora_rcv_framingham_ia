from pyspark.sql import SparkSession, DataFrame
from datetime import datetime
import ctypes
import os


class UtilsSpark:

    def __init__(self, databricks: bool, app_name: str = 'Spark_Oracle_Connection', config_options: dict = None):
        """
        Constructor que crea una SparkSession en función de las opciones de configuración que queramos añadir.

        -------------
        Parameters:
        :param databricks: Booleano para saber si queremos emplear Databricks y adoptar ciertas opciones de Spark.
        :param app_name: Nombre de la sesión de Spark.
        :param config_options: Diccionario con las diferentes opciones de configuración.
        """
        self.databricks = databricks
        self.spark = SparkSession.builder.appName(app_name)
        if not databricks:
            self.spark = self.spark.config('spark.executor.memory', '3g')
            self.spark = self.spark.config('spark.driver.memory', '3g')
        if config_options:
            for k in config_options:
                self.spark = self.spark.config(k, config_options[k])
        self.spark = self.spark.getOrCreate()
        if databricks:
            from pyspark.dbutils import DBUtils
            self.dbutils = DBUtils(self.spark)

    def obtener_tabla(self, driver: str, url: str, user: str, password: str, nombre_tabla: str) -> DataFrame:
        """
        Recibe los parámetros necesarios para conectar con una base de datos relacional a través del driver
        JDBC y obtener todos los registros de una tabla mediante SparkSQL.

        -------------
        Parameters:
        :param driver: Driver de JDBC para conectar con la base de datos.
        :param url: Dirección completa de la base de datos.
        :param user: Usuario para conectar con la base de datos.
        :param password: Contraseña del usuario para conectar con la base de datos.
        :param nombre_tabla: Nombre de la tabla de la cual queremos obtener sus registros.
        :return DataFrame con la tabla completa que queremos obtener.
        """
        return self.spark.read.format('jdbc').option(
            'driver', driver).option(
            'url', url).option(
            'dbtable', nombre_tabla).option(
            'user', user).option(
            'fetchsize', '100000').option(
            'batchsize', '100000').option(
            'password', password).load()

    def exportar_csv(self, resultado: DataFrame, nombre_carpeta: str = 'Resultado', aviso_windows: bool = True) -> None:
        """
        Para exportar un DataFrame de Spark a un archivo CSV recibimos por parámetro el propio DataFrame y
        el nombre de la carpeta en la que se incluirá el resultado. Por defecto esta carpeta será 'Resultado',
        pero, en un mismo trabajo, podríamos exportar más de un CSV. Por eso es necesario exportarlos en
        diferentes carpetas para que no se sobreescriban. La función además imprime por consola el tiempo
        que tarda en exportar los datos, ya que, en este punto, es en donde se aplican todos los trabajos que
        necesita llevar a cabo Spark y es útil registrar cuánto ha tardado. También es necesario cambiar la
        repartición de los datos a 1 para obtener un solo archivo CSV.

        -------------
        Parameters:
        :param resultado: Datos que queremos exportar en formato DataFrame de Spark.
        :param nombre_carpeta: Nombre de la carpeta que contendrá los datos exportados, por defecto, 'Resultado'.
        :param aviso_windows: Booleano para saber si emitimos un aviso para Windows cuando haya finalizado.
        Por defecto, sí.
        :return: None
        """
        comienzo = datetime.now()
        print(f'Comienzo: {str(comienzo)}')
        resultado.repartition(1).write.mode('overwrite').csv(path=f'./{nombre_carpeta}', header=True, sep=';')
        final = datetime.now()
        print(f'Fin: {str(final)}')
        print(f'Tiempo empleado:{str(final - comienzo)}')
        if self.databricks:
            self.dbutils.fs.cp(f'dbfs:/{nombre_carpeta}/',
                               f'file:{os.path.abspath("./").lstrip("C:")}/{nombre_carpeta}',
                               recurse=True)
            self.dbutils.fs.rm(f'dbfs:/{nombre_carpeta}/', recurse=True)
        if aviso_windows:
            ctypes.windll.user32.MessageBoxW(0,
                                             'La consulta en Spark ha finalizado correctamente.',
                                             'Consulta finalizada',
                                             64)

    def importar_archivo_databricks(self, nombre_archivo: str, destino: str = 'FileStore/otros'):
        """
        Método para copiar un archivo desde nuestro ordenador local al sistema DBFS de Hadoop integrado en
        Databricks.

        -------------
        Parameters:
        :param nombre_archivo: Nombre del archivo que queremos copiar incluyendola extensión. Debe encontrarse al
        mismo nivel que el script que ejecute este método.
        :param destino: Nombre del directorio de destino dentro de Hadoop, por defecto, 'FileStore/otros'. Debe existir.
        :return: None
        """
        self.dbutils.fs.cp(f'./{nombre_archivo}', f'dbfs:/{destino}/')
